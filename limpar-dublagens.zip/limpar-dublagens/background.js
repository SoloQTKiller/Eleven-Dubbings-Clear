chrome.action.onClicked.addListener(async tab => {
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      files: ["limpeza.js"]
    });
  } catch (erro) {
    await chrome.action.setBadgeText({ tabId: tab.id, text: "!" });
    await chrome.action.setTitle({ tabId: tab.id, title: "Abra a aba Dublagem do ElevenLabs" });
  }
});

