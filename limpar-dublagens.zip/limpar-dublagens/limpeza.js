(() => {
  if (location.origin !== "https://elevenlabs.io" ||
      !/^\/app\/dubbing\/?$/.test(location.pathname)) {
    alert("Abra a página Dublagem do ElevenLabs.");
    return;
  }

  const painelId = "limpeza-dublagens-extensao";
  if (document.getElementById(painelId)) return;

  const seletor = '[data-agent-id^="dubbing-project-list-row-"], [data-agent-id^="dubbing-list-row-"]';
  const opcoes = 'button[aria-label="Opções de dublagem"]';
  const linhas = () => [...document.querySelectorAll(seletor)];
  const buscar = id => document.querySelector(`[data-agent-id="${CSS.escape(id)}"]`);
  const visivel = el => el.getClientRects().length > 0 &&
    getComputedStyle(el).visibility === "visible";
  const caixas = () => [...document.querySelectorAll('[role="dialog"], [role="alertdialog"]')].filter(visivel);
  const pausa = ms => new Promise(resolve => setTimeout(resolve, ms));

  const painel = document.createElement("aside");
  painel.id = painelId;
  painel.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647";
  const ui = painel.attachShadow({ mode: "open" });
  ui.innerHTML = `
    <style>
      section{font:14px/1.45 system-ui,sans-serif;color:#18181b;background:#fff;width:min(320px,calc(100vw - 64px));padding:16px;border:1px solid #d4d4d8;border-radius:12px;box-shadow:0 8px 32px #0003}
      p{margin:8px 0} progress{display:block;width:100%;height:12px;accent-color:#a91e24} small{display:block;margin:6px 0;color:#52525b} button{font:inherit;padding:6px 10px;margin:4px 6px 0 0;border:1px solid #a1a1aa;background:#fafafa;color:#18181b;border-radius:6px;cursor:pointer}
      button:first-of-type{background:#a91e24;color:white;border-color:#a91e24} button[hidden]{display:none}
    </style>
    <section>
      <strong>Limpar dublagens</strong>
      <p role="status"></p>
      <progress aria-label="Entradas removidas"></progress>
      <small></small>
      <button type="button">Apagar histórico exibido</button>
      <button type="button">Fechar</button>
    </section>`;
  document.body.append(painel);

  const status = ui.querySelector("p");
  const [iniciar, fechar] = ui.querySelectorAll("button");
  const informar = mensagem => { status.textContent = mensagem; };
  informar(`${linhas().length} entradas carregadas. A limpeza segue os filtros atuais.`);
  const barra = ui.querySelector("progress");
  const legenda = ui.querySelector("small");
  function progresso(removidas, total) {
    barra.max = Math.max(1, total);
    barra.value = removidas;
    legenda.textContent = `${removidas}/${total} entradas removidas`;
  }
  progresso(0, linhas().length);
  let rodando = false;
  let parar = false;

  fechar.onclick = () => {
    if (rodando) {
      parar = true;
      informar("Parando após a operação atual…");
    } else {
      painel.remove();
    }
  };

  async function esperar(verificar, ms) {
    const fim = Date.now() + ms;
    do {
      const retorno = verificar();
      if (retorno) return retorno;
      await pausa(200);
    } while (Date.now() < fim);
    return null;
  }

  const pressionar = (el, key) => el.dispatchEvent(
    new KeyboardEvent("keydown", { key, bubbles: true, cancelable: true })
  );

  const assinatura = el => el.innerText.split("\n").map(s => s.trim())
    .filter(s => s && !/^(há\b|hoje\b|ontem\b|.*passad[oa]$)/i.test(s)).join("\n");

  async function remover(id) {
    const linha = buscar(id);
    if (!linha) return "saiu";
    if (caixas().length) throw new Error("Feche a caixa aberta no ElevenLabs.");
    const botao = linha.querySelector(opcoes);
    if (!botao || botao.disabled) throw new Error("Opções indisponíveis.");
    const antes = assinatura(linha);
    botao.scrollIntoView({ block: "center" });
    botao.click();

    const menu = await esperar(() => {
      const el = document.getElementById(botao.getAttribute("aria-controls"));
      return el?.matches('[cmdk-root][data-state="open"]') && visivel(el) && el;
    }, 4000);
    if (!menu) throw new Error("O menu do projeto não abriu.");

    pressionar(menu, "End");
    const selecionado = await esperar(() => menu.querySelector(
      '[role="option"][aria-selected="true"][data-value="Remover"][aria-disabled="false"]'
    ), 2000);
    if (!selecionado) throw new Error("O menu não selecionou Remover.");
    pressionar(menu, "Enter");

    const caixa = await esperar(() => caixas().find(el =>
      el.querySelector("h2")?.textContent.trim() === "Remover Dublagem"
    ), 5000);
    if (!caixa) throw new Error("A confirmação de remoção não abriu.");

    const confirmar = [...caixa.querySelectorAll("button")].find(el =>
      el.textContent.trim() === "Remover Dublagem" && visivel(el) && !el.disabled
    );
    if (!confirmar) throw new Error("Botão de confirmação indisponível.");
    if (parar) return "interrompido";
    confirmar.click();

    return await esperar(() => {
      if (caixa.isConnected && visivel(caixa)) return null;
      const atual = buscar(id);
      if (!atual) return "saiu";
      return assinatura(atual) !== antes ? "mudou" : null;
    }, 8000) ?? "sem alteração";
  }

  iniciar.onclick = async () => {
    if (rodando || !linhas().length) {
      if (!rodando) informar("Nenhuma entrada carregada. Confira a lista.");
      return;
    }
    if (prompt("Digite APAGAR para excluir permanentemente as dublagens que a lista carregar com os filtros atuais.")?.trim() !== "APAGAR") return;

    rodando = true;
    parar = false;
    iniciar.hidden = true;
    fechar.textContent = "Parar";
    const pendentes = new Set();
    const encontradas = new Set();
    const atualizarProgresso = () => {
      for (const linha of linhas()) encontradas.add(linha.dataset.agentId);
      progresso(removidas, encontradas.size);
    };
    let removidas = 0;
    let erro;
    atualizarProgresso();
    try {
      while (!parar) {
        atualizarProgresso();
        const projeto = linhas().find(el => !pendentes.has(el.dataset.agentId));
        if (!projeto) {
          linhas().at(-1)?.scrollIntoView({ block: "end" });
          const novos = await esperar(
            () => parar || linhas().some(el => !pendentes.has(el.dataset.agentId)), 6000
          );
          if (!novos) break;
          continue;
        }

        const id = projeto.dataset.agentId;
        let semMudanca = 0;
        for (let tentativa = 1; tentativa <= 30 && !parar; tentativa++) {
          atualizarProgresso();
          informar(`${removidas} entradas removidas. Tentativa ${tentativa} no item atual…`);
          const resultado = await remover(id);
          if (resultado === "interrompido") break;
          if (resultado === "saiu") {
            removidas++;
            atualizarProgresso();
            await pausa(1200);
            break;
          }
          semMudanca = resultado === "mudou" ? 0 : semMudanca + 1;
          if (semMudanca >= 3 || tentativa === 30) {
            pendentes.add(id);
            break;
          }
          await pausa(1200);
        }
      }
    } catch (falha) {
      erro = falha.message;
    } finally {
      atualizarProgresso();
      rodando = false;
      iniciar.hidden = false;
      fechar.textContent = "Fechar";
      const resumo = `${removidas} entradas removidas. ${linhas().length} ainda carregadas.`;
      informar(erro ? `${resumo} ${erro}` : `${resumo} ${parar ? "Limpeza interrompida." : "Recarregue para conferir o histórico."}`);
    }
  };
})();

